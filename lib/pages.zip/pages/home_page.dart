import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart' as latlong;
import 'package:nyari/business_profile_page.dart';
import 'package:nyari/search_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<DocumentSnapshot> _businesses = [];
  latlong.LatLng? _currentLocation;

  @override
  void initState() {
    super.initState();
    _fetchBusinesses();
  }

  Future<void> _fetchBusinesses() async {
    final querySnapshot =
        await FirebaseFirestore.instance.collection('businesses').get();
    final docs = querySnapshot.docs;

    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (serviceEnabled &&
        permission != LocationPermission.denied &&
        permission != LocationPermission.deniedForever) {
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      _currentLocation = latlong.LatLng(position.latitude, position.longitude);

      final distance = latlong.Distance();

      docs.sort((a, b) {
        final geoA = a['geo'] as GeoPoint?;
        final geoB = b['geo'] as GeoPoint?;
        if (geoA == null || geoB == null) return 0;

        final distanceA = distance(
          _currentLocation!,
          latlong.LatLng(geoA.latitude, geoA.longitude),
        );
        final distanceB = distance(
          _currentLocation!,
          latlong.LatLng(geoB.latitude, geoB.longitude),
        );
        return distanceA.compareTo(distanceB);
      });
    }

    setState(() {
      _businesses = docs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nyari 🗺️'),
        backgroundColor: const Color(0xFF201E50),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed:
                () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SearchPage()),
                ),
          ),
        ],
      ),
      body:
          _businesses.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                itemCount: _businesses.length,
                itemBuilder: (context, index) {
                  final business =
                      _businesses[index].data() as Map<String, dynamic>;
                  final name = business['name'] ?? 'No name';
                  final geo = business['geo'] as GeoPoint?;
                  final rating =
                      business['rating']?.toStringAsFixed(1) ?? 'No rating';

                  double? distanceInKm;
                  if (_currentLocation != null && geo != null) {
                    final businessLocation = latlong.LatLng(
                      geo.latitude,
                      geo.longitude,
                    );
                    distanceInKm = latlong.Distance().as(
                      latlong.LengthUnit.Kilometer,
                      _currentLocation!,
                      businessLocation,
                    );
                  }

                  return ListTile(
                    title: Text(name),
                    subtitle:
                        distanceInKm != null
                            ? Text('${distanceInKm.toStringAsFixed(1)} km away')
                            : const Text('Distance not available'),
                    trailing: Text('⭐ $rating'),
                    onTap:
                        () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (context) => BusinessProfilePage(
                                  businessId: _businesses[index].id,
                                  businessData: business,
                                ),
                          ),
                        ),
                  );
                },
              ),
    );
  }
}
