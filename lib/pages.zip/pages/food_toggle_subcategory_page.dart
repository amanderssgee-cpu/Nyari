import 'package:flutter/material.dart';

class FoodToggleSubcategoryPage extends StatefulWidget {
  final String categoryTitle;
  final List<String> subcategories;

  const FoodToggleSubcategoryPage({
    super.key,
    required this.categoryTitle,
    required this.subcategories,
  });

  @override
  State<FoodToggleSubcategoryPage> createState() =>
      _FoodToggleSubcategoryPageState();
}

class _FoodToggleSubcategoryPageState extends State<FoodToggleSubcategoryPage> {
  bool showCuisine = true;

  List<String> get cuisineList {
    final start = widget.subcategories.indexOf('▶️ By Cuisine') + 1;
    final end = widget.subcategories.indexOf('▶️ By Style');
    return widget.subcategories.sublist(start, end);
  }

  List<String> get styleList {
    final start = widget.subcategories.indexOf('▶️ By Style') + 1;
    return widget.subcategories.sublist(start);
  }

  @override
  Widget build(BuildContext context) {
    final selectedList = showCuisine ? cuisineList : styleList;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.categoryTitle),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: ToggleButtons(
              isSelected: [showCuisine, !showCuisine],
              onPressed: (index) {
                setState(() => showCuisine = index == 0);
              },
              borderRadius: BorderRadius.circular(20),
              selectedColor: Colors.white,
              fillColor: const Color(0xFF201E50),
              color: Colors.black,
              children: const [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text('By Cuisine'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text('By Style'),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 3 / 2,
              ),
              itemCount: selectedList.length,
              itemBuilder: (context, index) {
                final sub = selectedList[index];
                return GestureDetector(
                  onTap: () {
                    // TODO: Navigate to filtered business list for this subcategory
                  },
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 4,
                    child: Center(
                      child: Text(
                        sub,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
