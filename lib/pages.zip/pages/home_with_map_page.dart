import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:math' show cos, sqrt, asin;
import 'business_profile_page.dart';

class HomeWithMapPage extends StatefulWidget {
  const HomeWithMapPage({super.key});

  @override
  State<HomeWithMapPage> createState() => _HomeWithMapPageState();
}

class _HomeWithMapPageState extends State<HomeWithMapPage> {
  Position? _userLocation;
  final Set<Marker> _markers = {};
  GoogleMapController? _mapController;

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.deniedForever) return;
    }

    final position = await Geolocator.getCurrentPosition();
    setState(() {
      _userLocation = position;
    });
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const p = 0.017453292519943295;
    final a =
        0.5 -
        cos((lat2 - lat1) * p) / 2 +
        cos(lat1 * p) * cos(lat2 * p) * (1 - cos((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nyari 🗺️'),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search businesses...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 0,
                  horizontal: 16,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(-8.65, 115.2167),
                zoom: 12,
              ),
              markers: _markers,
              myLocationEnabled: true,
              onMapCreated: (controller) => _mapController = controller,
            ),
          ),
          Expanded(
            flex: 1,
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  FirebaseFirestore.instance
                      .collection('businesses')
                      .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final docs = snapshot.data!.docs;
                List<Map<String, dynamic>> businessList = [];
                Set<Marker> updatedMarkers = {};

                for (var doc in docs) {
                  final data = doc.data() as Map<String, dynamic>;
                  final geo = data['geo'];

                  if (geo == null) continue;

                  double distance = 0;
                  if (_userLocation != null) {
                    distance = calculateDistance(
                      _userLocation!.latitude,
                      _userLocation!.longitude,
                      geo.latitude,
                      geo.longitude,
                    );
                  }

                  final businessId = doc.id;
                  data['id'] = businessId;
                  data['distance'] = distance;

                  businessList.add(data);

                  updatedMarkers.add(
                    Marker(
                      markerId: MarkerId(businessId),
                      position: LatLng(geo.latitude, geo.longitude),
                      infoWindow: InfoWindow(title: data['name']),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder:
                                (_) => BusinessProfilePage(
                                  businessId: businessId,
                                  businessData: data,
                                ),
                          ),
                        );
                      },
                    ),
                  );
                }

                businessList.sort(
                  (a, b) => a['distance'].compareTo(b['distance']),
                );

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  setState(() {
                    _markers.clear();
                    _markers.addAll(updatedMarkers);
                  });
                });

                return ListView.builder(
                  itemCount: businessList.length,
                  itemBuilder: (context, index) {
                    final biz = businessList[index];
                    final rating = biz['rating'] ?? 0;

                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 6,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        title: Text(biz['name'] ?? 'No Name'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (_userLocation != null)
                              Text(
                                "${biz['distance'].toStringAsFixed(2)} km away",
                              ),
                            Row(
                              children: [
                                const Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  size: 18,
                                ),
                                const SizedBox(width: 4),
                                Text(rating.toString()),
                              ],
                            ),
                          ],
                        ),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (_) => BusinessProfilePage(
                                    businessId: biz['id'],
                                    businessData: biz,
                                  ),
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
