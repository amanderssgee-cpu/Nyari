import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'business_profile_page.dart';

class MapPage extends StatefulWidget {
  final String category;

  const MapPage({super.key, required this.category});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  List<QueryDocumentSnapshot> _businessDocs = [];
  TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedCategory = 'All';
  String _sortOption = 'Distance';

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.category;
    _requestLocationPermission();
    _loadBusinessMarkers();
  }

  Future<void> _requestLocationPermission() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      try {
        final position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 10),
        );
        setState(() {});
      } catch (e) {
        print('Failed to get location: $e');
      }
    } else {
      print('Location permission not granted');
    }
  }

  Future<void> _loadBusinessMarkers() async {
    try {
      final querySnapshot =
          await FirebaseFirestore.instance.collection('businesses').get();

      final filteredDocs =
          querySnapshot.docs.where((doc) {
            final category = doc['category'] ?? '';
            return _selectedCategory == 'All' || category == _selectedCategory;
          }).toList();

      if (_sortOption == 'Distance') {
        Position? userPosition;
        try {
          userPosition = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
          );
        } catch (e) {
          print('Error getting user position for sorting: $e');
        }

        if (userPosition != null) {
          final userLat = userPosition.latitude;
          final userLng = userPosition.longitude;

          filteredDocs.sort((a, b) {
            final aData = a.data() as Map<String, dynamic>;
            final bData = b.data() as Map<String, dynamic>;
            final aDist = Geolocator.distanceBetween(
              userLat,
              userLng,
              aData['lat'] ?? 0,
              aData['lng'] ?? 0,
            );
            final bDist = Geolocator.distanceBetween(
              userLat,
              userLng,
              bData['lat'] ?? 0,
              bData['lng'] ?? 0,
            );
            return aDist.compareTo(bDist);
          });
        }
      } else if (_sortOption == 'Rating') {
        filteredDocs.sort((a, b) {
          final aRating = (a['rating'] ?? 0).toDouble();
          final bRating = (b['rating'] ?? 0).toDouble();
          return bRating.compareTo(aRating);
        });
      }

      setState(() {
        _businessDocs = filteredDocs;
      });
    } catch (e) {
      print('Error loading markers: $e');
    }
  }

  Widget _buildBusinessList() {
    final filteredList =
        _businessDocs.where((doc) {
          final data = doc.data() as Map<String, dynamic>;
          final name = data['name'] ?? '';
          return _searchQuery.isEmpty ||
              name.toLowerCase().contains(_searchQuery);
        }).toList();

    return ListView.builder(
      itemCount: filteredList.length,
      itemBuilder: (context, index) {
        final doc = filteredList[index];
        final data = doc.data() as Map<String, dynamic>;
        final name = data['name'] ?? 'Unnamed';

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: ListTile(
            title: Text(
              name,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Row(
              children: [
                const Icon(Icons.star, color: Colors.amber, size: 16),
                const SizedBox(width: 4),
                if (data['rating'] != null && data['rating'] > 0)
                  Text(
                    data['rating'].toStringAsFixed(1),
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
              ],
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (_) => BusinessProfilePage(
                        businessData: data,
                        businessId: doc.id,
                      ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${_selectedCategory} Map'),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search businesses...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value.toLowerCase();
                    });
                  },
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 40,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children:
                        ['All', 'Food', 'Fitness', 'Beauty', 'Wellness'].map((
                          cat,
                        ) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 4.0,
                            ),
                            child: ChoiceChip(
                              label: Text(cat),
                              selected: _selectedCategory == cat,
                              onSelected: (_) {
                                setState(() {
                                  _selectedCategory = cat;
                                  _loadBusinessMarkers();
                                });
                              },
                            ),
                          );
                        }).toList(),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Sort by: "),
                    DropdownButton<String>(
                      value: _sortOption,
                      items:
                          ['Distance', 'Rating'].map((option) {
                            return DropdownMenuItem(
                              value: option,
                              child: Text(option),
                            );
                          }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _sortOption = value!;
                          _loadBusinessMarkers();
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ✅ Placeholder instead of crashing Google Map
          Container(
            height: 300,
            color: Colors.grey[300],
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.map, size: 50, color: Colors.grey),
                SizedBox(height: 8),
                Text(
                  'Map preview not available on this device',
                  style: TextStyle(color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),

          Expanded(child: _buildBusinessList()),
        ],
      ),
    );
  }
}
