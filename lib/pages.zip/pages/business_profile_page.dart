import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class BusinessProfilePage extends StatelessWidget {
  final Map<String, dynamic> businessData;
  final String businessId;

  const BusinessProfilePage({
    super.key,
    required this.businessData,
    required this.businessId,
  });

  @override
  Widget build(BuildContext context) {
    final name = businessData['name'] ?? 'No Name';
    final description = businessData['description'] ?? 'No description yet.';
    final location = businessData['location'] ?? 'Location not provided';
    final hours = businessData['hours'] ?? 'Not listed';
    final imageUrl = businessData['imageUrl'];
    final whatsapp = businessData['whatsapp'];
    final rating = businessData['rating'];

    return Scaffold(
      appBar: AppBar(
        title: Text(name),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (imageUrl != null)
              Image.network(imageUrl)
            else
              const SizedBox(height: 200, child: Placeholder()),

            const SizedBox(height: 12),
            Text(description, style: const TextStyle(fontSize: 16)),

            const SizedBox(height: 8),
            Text("📍 $location", style: const TextStyle(fontSize: 14)),
            Text("⏰ $hours", style: const TextStyle(fontSize: 14)),

            if (rating != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text("⭐ $rating", style: const TextStyle(fontSize: 14)),
              ),

            const SizedBox(height: 16),
            if (whatsapp != null)
              ElevatedButton.icon(
                onPressed: () async {
                  final url = Uri.parse('https://wa.me/$whatsapp');
                  if (await canLaunchUrl(url)) {
                    await launchUrl(url);
                  }
                },
                icon: const Icon(Icons.chat),
                label: const Text("Contact on WhatsApp"),
              ),
          ],
        ),
      ),
    );
  }
}
