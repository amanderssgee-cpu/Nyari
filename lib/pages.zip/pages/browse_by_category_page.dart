import 'package:flutter/material.dart';
import 'subcategory_page.dart';
import 'food_toggle_subcategory_page.dart'; // Add this new file

class BrowseByCategoryPage extends StatefulWidget {
  const BrowseByCategoryPage({super.key});

  @override
  State<BrowseByCategoryPage> createState() => _BrowseByCategoryPageState();
}

class _BrowseByCategoryPageState extends State<BrowseByCategoryPage> {
  final List<Map<String, dynamic>> allCategories = [
    {
      'title': 'Wellness 🧘',
      'subcategories': ['Massage', 'Bodywork', 'Healers & Mindful Practices'],
    },
    {
      'title': 'Fitness 💪',
      'subcategories': [
        'Gyms / Weight Training',
        'CrossFit',
        'Boxing / MMA',
        'Calisthenics',
        'Yoga',
        'Pilates',
        'Aerials',
      ],
    },
    {
      'title': 'Food & Drink 🍽',
      'subcategories': [
        '▶️ By Cuisine',
        'Indonesian',
        'Italian',
        'Mexican',
        'Japanese',
        'Chinese',
        'Indian',
        'Middle Eastern',
        'Western / American',
        'Vegan / Plant-Based',
        'Fusion / Contemporary',
        '▶️ By Style',
        'Warung',
        'Fine Dining',
        'Street Food',
        'Dessert & Bakeries',
        'Cafes & Coffee',
        'Smoothies & Juice Bars',
        'Beachfront Restaurants',
        'Late-Night Eats',
        'All-You-Can-Eat',
      ],
    },
    {
      'title': 'Beauty 💅',
      'subcategories': [
        'Hair',
        'Nails',
        'Lashes & Brows',
        'Waxing & Sugaring',
        'Laser & Skin',
        'Injectables / Aesthetics',
        'Facials / Skincare',
      ],
    },
    {
      'title': 'Shopping 🛍',
      'subcategories': [
        'Boutiques',
        'Jewelry',
        'Art & Home Decor',
        'Markets & Souvenirs',
        'Malls',
      ],
    },
    {
      'title': 'Experiences 🌴',
      'subcategories': [
        'Surf Lessons',
        'Cooking Classes',
        'ATV / Adventure Tours',
        'Temple Visits',
        'Selfie Museums / Studios',
        'Waterfalls & Nature Walks',
        'Horseback Riding',
        'Unique Rides / Views',
      ],
    },
    {
      'title': 'Nightlife 🎉',
      'subcategories': [
        'Beach Clubs',
        'Bars & Lounges',
        'Dance Clubs',
        'Late-Night Eateries',
      ],
    },
    {
      'title': 'Services 🛠',
      'subcategories': [
        'Coworking Spaces',
        'SIM Cards & Phone Services',
        'Tech Repair',
        'Scooter Rental',
        'Transportation / Drivers',
        'Laundry & Dry Cleaning',
        'Visa & Immigration Help',
        'Tailors & Alterations',
        'Banks & ATMs',
      ],
    },
    {
      'title': 'Stay 🏡',
      'subcategories': ['Hotels', 'Hostels'],
    },
    {'title': 'Tattoos 🖋', 'subcategories': []},
  ];

  String searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final filtered =
        allCategories.where((cat) {
          return cat['title'].toLowerCase().contains(searchQuery.toLowerCase());
        }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search categories...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(horizontal: 20),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide.none,
              ),
            ),
            onChanged: (value) {
              setState(() {
                searchQuery = value;
              });
            },
          ),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 3 / 2,
            ),
            itemCount: filtered.length,
            itemBuilder: (context, index) {
              final category = filtered[index];

              return GestureDetector(
                onTap: () {
                  final title = category['title'];
                  final subcategories = category['subcategories'];

                  if (title.contains('Food & Drink')) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (context) => FoodToggleSubcategoryPage(
                              categoryTitle: title,
                              subcategories: List<String>.from(subcategories),
                            ),
                      ),
                    );
                  } else if (subcategories.isNotEmpty) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (context) => SubcategoryPage(
                              categoryTitle: title,
                              subcategories: List<String>.from(subcategories),
                            ),
                      ),
                    );
                  } else {
                    // TODO: Navigate directly to filtered business list (e.g. Tattoos)
                  }
                },
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 4,
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(
                        category['title'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
