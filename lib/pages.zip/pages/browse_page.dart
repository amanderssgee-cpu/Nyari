import 'package:flutter/material.dart';
import 'browse_by_category_page.dart';

class BrowsePage extends StatelessWidget {
  const BrowsePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Browse Categories'),
        backgroundColor: Color(0xFF201E50),
      ),
      body: const BrowseByCategoryPage(),
    );
  }
}


// ===============================
// browse_by_category_page.dart (Category Grid)
// ===============================

import 'package:flutter/material.dart';
import 'subcategory_page.dart';

class BrowseByCategoryPage extends StatelessWidget {
  const BrowseByCategoryPage({super.key});

  final List<Map<String, dynamic>> categories = const [
    {
      'title': 'Wellness 🧘',
      'subcategories': ['Massage', 'Bodywork', 'Healers & Mindful Practices'],
    },
    {
      'title': 'Fitness 💪',
      'subcategories': [
        'Gyms / Weight Training',
        'CrossFit',
        'Boxing / MMA',
        'Calisthenics',
        'Yoga',
        'Pilates',
        'Aerials',
      ],
    },
    {
      'title': 'Beauty 💅',
      'subcategories': [
        'Hair',
        'Nails',
        'Lashes & Brows',
        'Waxing & Sugaring',
        'Laser & Skin',
        'Injectables / Aesthetics',
        'Facials / Skincare',
      ],
    },
    {
      'title': 'Tattoos 🖋',
      'subcategories': [],
    },
    // Add more categories as needed
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 3 / 2,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        final category = categories[index];
        return GestureDetector(
          onTap: () {
            final subcategories = category['subcategories'];
            final title = category['title'];

            if (subcategories.isNotEmpty) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SubcategoryPage(
                    categoryTitle: title,
                    subcategories: List<String>.from(subcategories),
                  ),
                ),
              );
            } else {
              // TODO: Navigate directly to filtered business list
            }
          },
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 4,
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Text(
                  category['title'],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}


// ===============================
// subcategory_page.dart (Subcategory List View)
// ===============================

import 'package:flutter/material.dart';

class SubcategoryPage extends StatelessWidget {
  final String categoryTitle;
  final List<String> subcategories;

  const SubcategoryPage({
    super.key,
    required this.categoryTitle,
    required this.subcategories,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(categoryTitle),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: subcategories.length,
        itemBuilder: (context, index) {
          final sub = subcategories[index];

          // Optional: Skip headers like ▶️ if using grouped lists
          if (sub.startsWith('▶️')) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(
                sub.replaceAll('▶️ ', ''),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF201E50),
                ),
              ),
            );
          }

          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 4,
            child: ListTile(
              title: Text(sub),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                // TODO: Navigate to filtered business list
              },
            ),
          );
        },
      ),
    );
  }
}
