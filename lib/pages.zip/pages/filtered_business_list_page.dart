import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'business_profile_page.dart';
import 'package:first_flutter_app/pages/business_profile_page.dart';

class FilteredBusinessListPage extends StatefulWidget {
  final String subcategoryName;

  const FilteredBusinessListPage({super.key, required this.subcategoryName});

  @override
  State<FilteredBusinessListPage> createState() =>
      _FilteredBusinessListPageState();
}

class _FilteredBusinessListPageState extends State<FilteredBusinessListPage> {
  Position? _userPosition;

  @override
  void initState() {
    super.initState();
    _getUserLocation();
  }

  Future<void> _getUserLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.deniedForever ||
          permission == LocationPermission.denied)
        return;
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    setState(() => _userPosition = position);
  }

  @override
  Widget build(BuildContext context) {
    final query = FirebaseFirestore.instance
        .collection('businesses')
        .where('subcategory', isEqualTo: widget.subcategoryName);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.subcategoryName),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: query.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return const Center(
              child: Text('Something went wrong. Please try again.'),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text(
                'No ${widget.subcategoryName.toLowerCase()} businesses found yet.',
                style: const TextStyle(fontSize: 16),
              ),
            );
          }

          final businesses = snapshot.data!.docs;

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: businesses.length,
            itemBuilder: (context, index) {
              final data = businesses[index].data() as Map<String, dynamic>;
              final businessId = businesses[index].id;

              double? distanceKm;
              if (_userPosition != null && data['geo'] != null) {
                distanceKm =
                    Geolocator.distanceBetween(
                      _userPosition!.latitude,
                      _userPosition!.longitude,
                      data['geo'].latitude,
                      data['geo'].longitude,
                    ) /
                    1000;
              }

              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 4,
                margin: const EdgeInsets.only(bottom: 16),
                child: ListTile(
                  title: Text(
                    data['name'] ?? 'No Name',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 16),
                      const SizedBox(width: 4),
                      Text('${(data['rating'] ?? 0).toStringAsFixed(1)}'),
                      if (distanceKm != null) ...[
                        const SizedBox(width: 12),
                        Text('${distanceKm.toStringAsFixed(1)} km away'),
                      ],
                    ],
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (context) => BusinessProfilePage(
                              businessData: data,
                              businessId: businessId,
                            ),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
