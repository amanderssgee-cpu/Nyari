import 'package:flutter/material.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search'),
        backgroundColor: Color(0xFF201E50),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              decoration: InputDecoration(
                hintText: 'Search for a business...',
                filled: true,
                fillColor: Colors.white,
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Results',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: const [
                  ListTile(
                    leading: Icon(Icons.store),
                    title: Text('Warung Enak'),
                    subtitle: Text('Canggu • Open 8am - 10pm'),
                  ),
                  ListTile(
                    leading: Icon(Icons.spa),
                    title: Text('Zen Yoga Studio'),
                    subtitle: Text('Ubud • Open 6am - 9pm'),
                  ),
                  ListTile(
                    leading: Icon(Icons.coffee),
                    title: Text('Kopi Kita'),
                    subtitle: Text('Seminyak • Open 7am - 5pm'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
