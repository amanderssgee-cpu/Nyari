import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'business_profile_page.dart';

class FilteredListPage extends StatelessWidget {
  final String category;
  final String subcategory;

  const FilteredListPage({
    super.key,
    required this.category,
    required this.subcategory,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('$subcategory in $category'),
        backgroundColor: Color(0xFF201E50),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream:
            FirebaseFirestore.instance
                .collection('businesses')
                .where('category', isEqualTo: category)
                .where('subcategory', isEqualTo: subcategory)
                .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          final docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return Center(
              child: Text('No businesses found for this subcategory.'),
            );
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              final id = docs[index].id;
              final name = data['name'] ?? 'No Name';
              final location = data['location'] ?? 'No location';

              return ListTile(
                title: Text(name),
                subtitle: Text(location),
                trailing: Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (context) => BusinessProfilePage(
                            businessData: data,
                            businessId: id,
                          ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
