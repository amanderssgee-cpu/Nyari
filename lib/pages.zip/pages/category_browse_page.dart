import 'package:flutter/material.dart';

class CategoryBrowsePage extends StatelessWidget {
  final String category;
  final List<String> subcategories;

  const CategoryBrowsePage({
    super.key,
    required this.category,
    required this.subcategories,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(category),
        backgroundColor: const Color(0xFF201E50),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: subcategories.length,
          itemBuilder: (context, index) {
            final sub = subcategories[index];
            return Card(
              child: ListTile(
                title: Text(sub),
                onTap: () {
                  // 🧠 Eventually: Navigate to subcategory-specific business list
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(SnackBar(content: Text('Tapped on $sub')));
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
