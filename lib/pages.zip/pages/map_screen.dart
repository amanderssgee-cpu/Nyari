import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapController;
  Set<Marker> markers = {};

  @override
  void initState() {
    super.initState();
    _loadAllMarkers(); // load everything for now
  }

  Future<void> _loadAllMarkers() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('businesses').get();

    final loadedMarkers =
        snapshot.docs
            .map((doc) {
              final data = doc.data();
              final lat = data['lat']?.toDouble();
              final lng = data['lng']?.toDouble();
              final name = data['name'] ?? 'No Name';

              if (lat == null || lng == null) return null;

              return Marker(
                markerId: MarkerId(doc.id),
                position: LatLng(lat, lng),
                infoWindow: InfoWindow(title: name),
              );
            })
            .whereType<Marker>()
            .toSet();

    setState(() {
      markers = loadedMarkers;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Map View')),
      body: GoogleMap(
        initialCameraPosition: const CameraPosition(
          target: LatLng(-8.65, 115.137), // Default Bali area
          zoom: 13,
        ),
        onMapCreated: (controller) => mapController = controller,
        markers: markers,
      ),
    );
  }
}
